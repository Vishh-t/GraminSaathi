---
name: GraminSaathi Design System
colors:
  surface: '#f9f9ff'
  surface-dim: '#d3daef'
  surface-bright: '#f9f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f1f3ff'
  surface-container: '#e9edff'
  surface-container-high: '#e1e8fd'
  surface-container-highest: '#dce2f7'
  on-surface: '#141b2b'
  on-surface-variant: '#404940'
  inverse-surface: '#293040'
  inverse-on-surface: '#edf0ff'
  outline: '#707a6f'
  outline-variant: '#bfc9bd'
  surface-tint: '#1f6c3a'
  primary: '#004c22'
  on-primary: '#ffffff'
  primary-container: '#166534'
  on-primary-container: '#93e0a2'
  inverse-primary: '#8bd79b'
  secondary: '#006e2d'
  on-secondary: '#ffffff'
  secondary-container: '#7cf994'
  on-secondary-container: '#007230'
  tertiary: '#00389b'
  on-tertiary: '#ffffff'
  tertiary-container: '#004dcd'
  on-tertiary-container: '#bfcdff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#a6f4b5'
  primary-fixed-dim: '#8bd79b'
  on-primary-fixed: '#00210b'
  on-primary-fixed-variant: '#005226'
  secondary-fixed: '#7ffc97'
  secondary-fixed-dim: '#62df7d'
  on-secondary-fixed: '#002109'
  on-secondary-fixed-variant: '#005320'
  tertiary-fixed: '#dbe1ff'
  tertiary-fixed-dim: '#b4c5ff'
  on-tertiary-fixed: '#00174b'
  on-tertiary-fixed-variant: '#003ea8'
  background: '#f9f9ff'
  on-background: '#141b2b'
  surface-variant: '#dce2f7'
  success: '#16a34a'
  warning: '#f59e0b'
  danger: '#dc2626'
  surface-subtle: '#f0fdf4'
  background-main: '#f9fafb'
  muted: '#6b7280'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-sm:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '500'
    lineHeight: 26px
  body-base:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
  caption-xs:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  container-margin: 16px
  gutter: 16px
---

## Brand & Style

The design system is engineered to project **Trust, Authority, and Stability**, mirroring the visual language of established government institutions to build immediate credibility with rural entrepreneurs. The aesthetic is **Corporate / Modern** with a strong emphasis on functional clarity and information density.

The target audience requires a UI that feels reliable and supportive rather than experimental. By utilizing a "Government Scheme" aesthetic—characterized by deep greens, structured white surfaces, and clear semantic signaling—the system bridges the gap between sophisticated financial advisory and accessible local support. The personality is that of a "Digital Mentor": professional, approachable, and disciplined.

**Key Design Principles:**
- **Authority through Color:** Heavy use of `#166534` to evoke institutional trust.
- **Functional Minimalism:** Whitespace is used to separate data points, not just for aesthetics, ensuring low-end devices display content clearly.
- **Semantic Primacy:** Color is never decorative; it is always used to communicate risk or status (Red/Yellow/Green).
- **Localized Context:** Support for Indian numbering (Lakhs/Crores) and bilingual layouts are native to the visual structure.

## Colors

The palette is anchored by **Govt Green**, which serves as the primary brand anchor. This color is reserved for high-level headers, primary action buttons, and trust-building elements like the "Official Advisor" badges.

The semantic logic is strictly enforced across the application:
- **Primary Green (#166534):** Used for brand identity and primary navigation.
- **Success Green (#16a34a):** Indicates positive health scores and safe financial metrics (DSCR ≥ 2.0).
- **Warning Amber (#f59e0b):** Flags moderate risk and items requiring attention.
- **Danger Red (#dc2626):** Critical alerts, financial deficits, and high-risk indicators.
- **Neutral Surface:** A clean, slightly cool gray-white background ensures that the semantic colors stand out without visual vibration.

## Typography

This design system uses **Inter** for all Latin text, chosen for its exceptional legibility on mobile screens and its neutral, professional tone. While not explicitly tokenized in the JSON, all implementations must pair Inter with **Noto Sans Devanagari** for Hindi text.

**Formatting Rules:**
- **Bilingual Scale:** Hindi text naturally expands; the UI must account for a 1.3x increase in character width. Avoid fixed-width containers for labels.
- **Indian Numbering System:** All financial figures must be formatted as `en-IN` (e.g., 10,00,000 for 10 Lakhs).
- **Visual Hierarchy:** Headlines use Semibold (600) weights to ensure they stand out against dense data tables. Captions use a lighter weight but maintain a minimum 12px size to remain accessible on varied screen qualities.

## Layout & Spacing

The system follows a **Mobile-First Fluid Grid** philosophy. Since the primary interaction happens on smartphones, the layout is designed to stack vertically with high-touch targets.

- **Mobile (<640px):** Single column with 16px side margins. Cards are full-width or slightly inset.
- **Tablet (640px - 1024px):** Two-column symmetrical grid for dashboard metrics.
- **Desktop (>1024px):** Three-column layout or fixed-width center container (max 1280px) to prevent line lengths from becoming unreadable.

**Rhythm:** A 4px base unit ensures consistency. Input fields and interactive components should maintain a minimum height of 48px to accommodate touch interaction in outdoor or transit environments.

## Elevation & Depth

To ensure clarity for users with varying levels of digital literacy, depth is handled with **Tonal Layers and Low-Contrast Outlines**.

- **Cards:** Use a flat white surface with a `1px` border in `--border` (Gray-200). A very soft, diffused shadow (0px 2px 4px rgba(0,0,0,0.05)) is applied to distinguish the card from the light gray background.
- **Primary Elevation:** Floating Action Buttons (like the Voice/Mic trigger) use a more pronounced shadow to indicate they are the top-most interactive layer.
- **Active States:** When a card or element is selected, the border thickness increases to `2px` and changes to `--primary` green, rather than using heavy drop shadows.

## Shapes

The shape language is **Rounded**, striking a balance between the rigidity of a government form and the approachability of a modern app.

- **Standard Containers:** Cards and input fields use a **8px (rounded-lg)** radius. This provides a soft enough look to feel modern but retains enough structure to feel professional.
- **Interactive Elements:** Buttons follow the 8px standard.
- **Status Pills:** Badges for "Safe," "Risk," or "Live" use a **9999px (rounded-full)** pill shape to distinguish them from actionable buttons.
- **Large Components:** Modals and bottom sheets use a **12px (rounded-xl)** top-corner radius to signal they are temporary overlays.

## Components

### Buttons
- **Primary:** Solid `--primary` green background with white text. High contrast, 48px minimum height.
- **Secondary:** Ghost style with `--primary` border and text. 
- **Voice Button:** A circular, floating button featuring the `Mic` icon, utilizing a subtle pulse animation when active.

### Cards
- **Stat Cards:** White background, 8px radius, featuring a clear label, a large value, and a small semantic trend indicator (e.g., a green `TrendingUp` icon).
- **Advisory Cards:** Feature a left-hand accent border (4px) colored by risk status (Red/Yellow/Green).

### Form Fields
- Labels must always be visible (not placeholder-only).
- Input strokes use `--border` (Gray-200), changing to `--primary` on focus.
- Error states use `--danger` red text and borders.

### Chips & Badges
- Used for categories or status.
- Text-only chips use `--primary-bg` (light green) with `--primary` text for a soft, accessible look.

### Data Visualization
- **Charts:** Use simple line graphs with high-contrast points. 
- **Icons:** Use Lucide-style outline icons. Ensure all icons have a minimum 24x24px hit area.